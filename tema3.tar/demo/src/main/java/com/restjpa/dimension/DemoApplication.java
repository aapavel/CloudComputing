package com.restjpa.dimension;

import java.util.List;
import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.shell.standard.ShellComponent;
import org.springframework.shell.standard.ShellMethod;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@ShellComponent
@SpringBootApplication
@RequestMapping("dimension")
@RestController
public class DemoApplication {
  @Autowired
  DimensionRepository dimensionRepository;

  public static void main(String[] args) {
     SpringApplication.run(DemoApplication.class, args);
  }

  @ShellMethod("Saves a dimension to Cloud Datastore: save-dimension <type> <description> <year>")
  public String saveDimension(Dimension dimension) {
     Dimension savedDimension = dimensionRepository.save(dimension);
     return savedDimension.toString();
  }
  
  @GetMapping(value="/all")
  @ShellMethod("Loads all dimensions")
  public String findAllDimensions() {
     Iterable<Dimension> dimensions = this.dimensionRepository.findAll();
     return Lists.newArrayList(dimensions).toString();
  }

  @GetMapping(value="/all/{type}")
  @ShellMethod("Loads dimensions by type: find-by-type <type>")
  public String findByType(@PathVariable(name ="type") String type) {
     List<Dimension> dimensions = this.dimensionRepository.findByType(type);
     return dimensions.toString();
  }

  @GetMapping(value="/all/{year}")
  @ShellMethod("Loads dimensions published after a given year: find-by-year-after <year>")
  public String findByYearAfter(@PathVariable(name ="year")int year) {
     List<Dimension> dimensions = this.dimensionRepository.findByYearGreaterThan(year);
     return dimensions.toString();
  }


  @ShellMethod("Loads dimensions by type and year: find-by-type-year <type> <year>")
  public String findByTypeYear(String type, int year) {
     List<Dimension> dimensions = this.dimensionRepository.findByTypeAndYear(type, year);
     return dimensions.toString();
  }

   @DeleteMapping("/delete")
  @ShellMethod("Removes all dimensions")
  public void removeAllDimensions() {
     this.dimensionRepository.deleteAll();
  }
}