package com.restjpa.dimension;
import javax.annotation.Generated;
import org.springframework.cloud.gcp.data.datastore.core.mapping.Entity;
import org.springframework.cloud.gcp.data.datastore.core.mapping.Field;
import org.springframework.data.annotation.Id;


@Entity(name = "dimensions")
public class Dimension {
        @Id
        Long id;

        @Field(name="type")
        String type;

        @Field(name="description")
        String description;
        
        @Field(name="year")
        int year;

        public Dimension(String type, String description, int year) {
                this.type = type;
                this.description = description;
                this.year = year;
        }

        public long getId() {
                return this.id;
        }

        @Override
        public String toString() {
                return "Dimension{" +
                                "id=" + this.id +
                                ", type='" + this.type + '\'' +
                                ", description='" + this.description + '\'' +
                                ", year=" + this.year +
                                '}';
        }
}