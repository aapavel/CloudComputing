package com.restjpa.dimension;
import java.util.List;

import org.springframework.cloud.gcp.data.datastore.repository.DatastoreRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DimensionRepository extends DatastoreRepository<Dimension, Long> {

  List<Dimension> findByType(String type);

  List<Dimension> findByYearGreaterThan(int year);

  List<Dimension> findByTypeAndYear(String type, int year);
  
  

}